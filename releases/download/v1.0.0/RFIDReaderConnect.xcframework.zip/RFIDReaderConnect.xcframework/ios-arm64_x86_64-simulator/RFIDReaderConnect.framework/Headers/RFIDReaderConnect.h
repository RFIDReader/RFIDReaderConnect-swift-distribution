//
//  RFIDReaderConnect.h
//  RFIDReaderConnect
//
//  Created by Pratham Jaiswal on 23/03/24.
//

#import <Foundation/Foundation.h>

//! Project version number for RFIDReaderConnect.
FOUNDATION_EXPORT double RFIDReaderConnectVersionNumber;

//! Project version string for RFIDReaderConnect.
FOUNDATION_EXPORT const unsigned char RFIDReaderConnectVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <RFIDReaderConnect/PublicHeader.h>


